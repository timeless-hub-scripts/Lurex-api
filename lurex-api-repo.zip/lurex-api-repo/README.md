# LUREX API

This repository runs the LUREX obfuscation API, hosted loader, verification routes, key management, access control, and panel backend.

Railway starts the service with `python3 railway_api.py`.
