"""Compatibility launcher for Railway services still using the legacy nested path."""
from pathlib import Path
import runpy
import sys

ROOT_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT_DIR))
runpy.run_path(str(ROOT_DIR / "railway_api.py"), run_name="__main__")
