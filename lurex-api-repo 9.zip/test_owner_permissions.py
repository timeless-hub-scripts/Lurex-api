import json
import os
import sys

os.environ.pop("DATABASE_URL", None)
os.environ.pop("POSTGRES_URL", None)
os.environ.pop("POSTGRES_URL_NON_POOLING", None)
sys.path.insert(0, os.path.dirname(__file__))

import fine_store
import api.index as api

fine_store._MEM["loaders"].clear()
fine_store._MEM["sids"].clear()
fine_store._MEM["delegates"].clear()
fine_store.save_loader("perm123", "SCRIPT_ID-perm", "print('ok')", "Permission Script",
                       owner=json.dumps({"user_id": "creator-1", "owner_key": "OWNER-test"}), free=True)

class FakeHandler:
    headers = {"host": "example.test"}
    def _json(self, status, payload):
        return status, payload

fake = FakeHandler()
assert fine_store.list_by_user("creator-1")[0]["sid"] == "SCRIPT_ID-perm"
assert api.handler._manage(fake, "setadmin", {"script_id": "SCRIPT_ID-perm", "actor_id": "other", "subject_type": "member", "subject_id": "7"})[0] == 403
assert api.handler._manage(fake, "setadmin", {"script_id": "SCRIPT_ID-perm", "actor_id": "creator-1", "subject_type": "member", "subject_id": "7"})[0] == 200
assert api.handler._manage(fake, "setwl", {"script_id": "SCRIPT_ID-perm", "actor_id": "creator-1", "subject_type": "member", "subject_id": "7", "scope": "whitelist"})[0] == 200
assert api.handler._manage(fake, "rmwl", {"script_id": "SCRIPT_ID-perm", "actor_id": "creator-1", "subject_type": "member", "subject_id": "7", "scope": "all"})[0] == 200
assert not fine_store.can_delegate("perm123", "7", "whitelist")
print("owner permission boundary test passed")
