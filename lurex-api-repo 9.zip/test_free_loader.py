import os
import sys

os.environ.pop("DATABASE_URL", None)
os.environ.pop("POSTGRES_URL", None)
os.environ.pop("POSTGRES_URL_NON_POOLING", None)
sys.path.insert(0, os.path.dirname(__file__))

import fine_store
import api.index as api

fine_store._MEM["loaders"].clear()
fine_store._MEM["sids"].clear()
fine_store.save_loader("abc123", "SCRIPT_ID-test", "-- protected free chunk\nprint('ok')", "Free Script", owner='{"user_id":"42"}', free=True, source="print('ok')")
record = fine_store.load_loader("abc123")
assert record["free"] is True, record
assert api._validate("abc123", record, "", "")[0] is True
assert api._hex_hash("/loaders/abc123.lua", "") == "abc123"

class FakeHandler:
    def __init__(self):
        self.headers = {"host": "example.test"}
        self.result = None
    def _text(self, status, body):
        self.result = (status, body)
        return self.result

fake = FakeHandler()
result = api.handler._serve_loader(fake, "/loaders/abc123.lua", "")
assert result == (200, "-- protected free chunk\nprint('ok')"), result
print("free-loader regression test passed")
