# LUREX API service deployment

The repository already contains the complete Python API in `railway_api.py`. It exposes the health endpoint, obfuscation endpoint, hosted loader routes, verification routes, key management, ACL management, and public panel actions used by the LUREX Discord bot.

## Railway service

Create a second service in the same Railway project from this repository. Keep the existing bot service unchanged. For the API service, set the start command to:

```bash
python railway_api.py
```

The included `railway-api.json` records that same start command. Railway may still use the root `railway.json`, which intentionally starts the bot, so set the API service's Start Command explicitly in its service settings.

## Required API variables

| Variable | Value |
|---|---|
| `BOT_SHARED_SECRET` | A long random secret. Use exactly the same value on the Discord bot service. |
| `PUBLIC_BASE_URL` | The public Railway domain of the API, including `https://`, with no trailing slash. |
| `MAX_BYTES` | Optional; use `1000000` unless a different upload limit is required. |
| `DATABASE_URL` | A Railway Postgres connection string if scripts, keys, and ACLs must survive redeploys. |

The bot service must use these matching values:

```text
OBF_BACKEND=api
API_URL=https://YOUR-API-DOMAIN/api
BOT_SHARED_SECRET=THE-SAME-SECRET-AS-THE-API
```

After Railway assigns the API domain, update `PUBLIC_BASE_URL` to that domain and set the bot's `API_URL` to the API domain plus `/api`.

## Health check

Open:

```text
https://YOUR-API-DOMAIN/api/health
```

A healthy response contains `"name":"LUREX"`, `"status":"ok"`, and a storage status. If storage reports `ephemeral`, the API is running but no Postgres connection is configured; loaders and keys will be lost when the service restarts.

## API contract used by the bot

The bot sends obfuscation requests to `POST /api`. Management requests also use `POST /api` with actions such as `info`, `update`, `delete`, `freeze`, `unfreeze`, `set_free`, `genkey`, `delkey`, `listkeys`, `whitelist`, `blacklist`, `unlist`, and `listacl`. Public panel actions use `panel_info`, `redeem`, `get_script`, `reset_hwid`, `buyer_check`, and `key_info`.

Hosted loader URLs follow this pattern:

```text
https://YOUR-API-DOMAIN/loaders/PROJECT_ID.lua
```

The generated loader string is returned by the API and should be copied from the bot or panel rather than manually guessed.
