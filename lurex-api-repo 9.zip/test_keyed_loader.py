import os
import sys

os.environ.pop("DATABASE_URL", None)
os.environ.pop("POSTGRES_URL", None)
os.environ.pop("POSTGRES_URL_NON_POOLING", None)
sys.path.insert(0, os.path.dirname(__file__))

import api.index as api

loader = api._keyed_loadstring("https://api.example/loaders/abc.lua", "LUREX-123-456-789")
lines = loader.splitlines()

assert lines == [
    'script_key = "LUREX-123-456-789"',
    'loadstring(game:HttpGet("https://api.example/loaders/abc.lua"))()',
], lines
print("keyed-loader regression test passed")
