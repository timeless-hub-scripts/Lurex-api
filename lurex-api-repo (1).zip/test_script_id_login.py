import fine_store

fine_store._MEM["loaders"].clear()
fine_store._MEM["sids"].clear()

fine_store.save_loader(
    "loader-login-test",
    "SCRIPT_ID-e3rKcz48udmUCHG8K1H6peC",
    "-- protected",
    "Login Test",
    owner='{"user_id":"discord-user"}',
    free=False,
    source="print('ok')",
)

for supplied in (
    "SCRIPT_ID-e3rKcz48udmUCHG8K1H6peC",
    "e3rKcz48udmUCHG8K1H6peC",
    "script_id:e3rKcz48udmUCHG8K1H6peC",
):
    loader_hash, record = fine_store.resolve_sid(supplied)
    assert loader_hash == "loader-login-test", supplied
    assert record["name"] == "Login Test", supplied

print("script ID login normalization passed")
