import json
import fine_store

fine_store._DSN = None
fine_store._MEM = {"loaders": {}, "sids": {}, "keys": {}, "acl": {}, "delegates": {}, "audit": []}
fine_store.save_loader("hash-demo", "SCRIPT_ID-demo", "return true", "Demo Script", owner=json.dumps({"user_id": "discord-user-1"}))
rows = fine_store.list_by_user("discord-user-1")
assert len(rows) == 1
assert rows[0]["sid"] == "SCRIPT_ID-demo"
assert rows[0]["name"] == "Demo Script"
print("owner listing regression checks passed")
