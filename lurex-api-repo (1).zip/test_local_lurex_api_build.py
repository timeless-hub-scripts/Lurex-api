import api.index as api

result = api._build('print("hello")', {"engine": "LUREX", "silent": True})
assert isinstance(result, str) and len(result) > 1000
assert "obfuscated with LUREX" in result
assert result.startswith("--[[ obfuscated with LUREX v")
assert '"obfuscated"' not in result
assert "hello" not in result
print({"engine": "LUREX", "output_bytes": len(result), "local_engine": True})
