from api.index import _prometheus_build

source = 'local message = "hello"\nprint(message)\n'
output = _prometheus_build(source, "Medium")
assert output and output != source
assert len(output) > len(source)
print({"engine": "PROMETHEUS", "input_bytes": len(source), "output_bytes": len(output)})
