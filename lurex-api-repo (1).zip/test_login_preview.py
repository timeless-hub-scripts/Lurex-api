from pathlib import Path
import bot

assert callable(bot.keys_cmd), type(bot.keys_cmd)
assert callable(bot.access_cmd), type(bot.access_cmd)
assert callable(bot.delkey_cmd), type(bot.delkey_cmd)
assert callable(bot.blacklist_cmd), type(bot.blacklist_cmd)
source = Path(__file__).with_name("bot.py").read_text()
assert source.count("Optional SCRIPT_ID-; leave blank to choose a script preview") >= 4
assert "description=f\"{sid} · press to select\"" in source
assert bot._canonical_script_id("e3rKcz48udmUCHG8K1H6peC") == "SCRIPT_ID-e3rKcz48udmUCHG8K1H6peC"
assert bot._canonical_script_id("script_id:e3rKcz48udmUCHG8K1H6peC") == "SCRIPT_ID-e3rKcz48udmUCHG8K1H6peC"
assert bot._canonical_script_id("SCRIPT_ID-e3rKcz48udmUCHG8K1H6peC") == "SCRIPT_ID-e3rKcz48udmUCHG8K1H6peC"
print("preview command and login normalization checks passed")
