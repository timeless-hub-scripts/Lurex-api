# LUREX Security Boundary

## Purpose

This document records what is intentionally present in a generated user-facing script and what must remain exclusively on the LUREX API, database, or bot service. It is a containment guide, not a claim that client-executed Lua can be made impossible to inspect. Any code that executes on a user's Roblox client can ultimately be observed by a sufficiently capable operator.

## Generated-script trace

| Artifact or value | Embedded in the generated client output? | Boundary and rationale |
|---|---:|---|
| Obfuscated program payload | Yes, in LUREX and local Prometheus outputs | It must execute on the Roblox client. The LUREX build uses VM compilation, encrypted/encoded payload data, per-build mutation, and anti-tamper checks to raise the cost of inspection; these are defensive barriers, not secrecy from the client. |
| Anti-tamper and Roblox environment checks | Yes | These checks execute beside the protected payload and therefore are necessarily client-visible. |
| Loader gateway URL and project hash | Yes, in hosted loader gateways | The gateway needs a public URL and a non-secret project reference to reach the server verification route. |
| User-supplied `script_key` and runtime HWID | Supplied at runtime, not baked into the protected source | The gateway reads the key and HWID at execution time and sends them to the verification endpoint. Keys must never be treated as source-protection secrets. |
| Owner key, buyer/whitelist/admin role IDs, ACL records, key database, frozen state | No | These remain in server-side storage and are accessed through authenticated management actions. |
| Discord bot token, OAuth credentials, shared API secrets, external obfuscator token | No | These are server environment variables only. They must never be interpolated into Lua, returned in JSON, logged, or sent to the external obfuscator. |
| Bot command handlers and website management logic | No | The client receives only a loader or protected program. Discord control remains in `bot.py`, the website/API, and the database. |
| Original source | No, after server-side processing | The external LUREX route receives source over an authenticated server-to-server request. The local engine compiles source into its protected representation. Source should not be returned in API responses or persisted in client-visible metadata. |

## Current server-only boundary

The API adapter sends only `source` and a fixed allow-listed `options` object to the external LUREX endpoint. The bearer credential is read from `LUREX_EXTERNAL_OBFUSCATOR_TOKEN` and added to the outbound `Authorization` header inside the server process. The generated client artifact is read from the external response's `obfuscated` field; no external response headers, environment values, or internal request metadata are copied into the artifact.

The hosted gateway contains only a public base URL and project hash. It reads `script_key` and the Roblox HWID at runtime, calls the verification route, and executes the server response. Verification, key lookup, blacklist checks, HWID binding, freeze state, script storage, and management authorization remain on the API/database side. The Discord bot calls the API for management operations and does not place its token or command implementation into generated scripts.

> **Security ceiling:** the protected payload and its runtime must be available to the Roblox client. A user who can execute the script can instrument that runtime. LUREX hardening should therefore be described as increasing resistance, reducing accidental disclosure, and enforcing server-side authorization—not as making client-side source recovery mathematically impossible.

## Containment requirements

1. **Keep secrets in deployment configuration.** Set `LUREX_EXTERNAL_OBFUSCATOR_TOKEN`, `DISCORD_BOT_TOKEN`, OAuth credentials, JWT/shared secrets, and database credentials only in the API/bot service environment. Do not place them in Lua templates, frontend bundles, ZIP examples, Discord embeds, or error messages.
2. **Keep management server-side.** Require authenticated API actions for update, delete, freeze, key generation/revocation, ACL changes, role configuration, and owner views. Treat identifiers shown to users as selectors, not bearer secrets, unless explicitly designed as a private credential.
3. **Keep API responses minimal.** Return the protected output, loader metadata, and the identifiers required by the selected workflow. Never return the original source, environment configuration, external API response headers, database connection data, or bot source.
4. **Use server-side verification for access control.** The client gateway may collect a key and HWID, but it must not decide whether a key is valid, whether a user is blacklisted, or whether a script is frozen. Those decisions belong to the API and database.
5. **Protect logs and artifacts.** Redact `Authorization` headers, tokens, owner keys, raw source, and HWIDs from logs. Rebuild deployment archives from source while excluding `.env`, caches, local databases, and debug dumps.
6. **Assume client output is recoverable.** Do not put a Discord bot token, API shared secret, signing key, private role map, or privileged management endpoint into the protected Lua. If a value would let a user impersonate the bot or modify another user's script, it does not belong in generated output.
7. **Rotate after exposure.** If source, a token, or an owner credential is disclosed, revoke or rotate it first, then rebuild affected loaders and inspect audit logs. Anti-tamper changes alone do not invalidate an exposed server credential.

## Verification checklist

The repository's regression checks should confirm that the external adapter uses the fixed strong option set, that the bearer token is only referenced in server-side Python, that the gateway contains no secret placeholders, that generated loaders do not include bot/OAuth/database environment names, and that the API archive excludes transient cache files. These checks complement—not replace—secret scanning and deployment-provider log review.
